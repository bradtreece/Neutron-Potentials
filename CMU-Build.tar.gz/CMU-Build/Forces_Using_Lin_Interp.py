import numpy as np
#import matplotlib.pyplot as plt

#######################
### List of Targets ###
#######################

### This list contains the atoms that will be targeted by the forces. 
### Alternatively, inequalities can be used if atoms are contained in specific range.
### A target list must end in -1 for the if conditional (that pinpoints atoms) to work
TargetList = [i for i in np.arange(262)+1]
TargetList.append(-1) #This permits comparison after the target list has been exhausted

#################################################
### Import Coordinates for Simulation Density ###
#################################################

CoordFile = open('/home/tgr/Desktop/TestRun/ExtCoord.txt', "r")
line_split = CoordFile.readlines()
CoordFile.close()


ForceFile = open('/home/tgr/Desktop/TestRun/ExtForce.txt', "w")


##############################
### Managing the Densities ###
##############################

### Potential bounds and grid spacing
zmin = -50.
zmax = 50.
zstep = 1.

### The experimental density is flat for the example. Should be normalized differently though
Rho_EXP = np.array([  4.77670036e-88,   2.34977108e-82,   7.41442546e-77,   1.50074887e-71,   1.94869929e-66,   1.62337820e-61,
         8.67699375e-57,   2.97601971e-52,   6.55040580e-48,   9.25387046e-44,   8.39204793e-40,   4.88629861e-36,
         1.82705673e-32,   4.38827895e-29,   6.77234354e-26,   6.71810618e-23,   4.28562975e-20,   1.75908261e-17,
         4.64908754e-15,   7.91860197e-13,   8.70224541e-11,   6.17981921e-09,   2.84160079e-07,   8.48389025e-06,
         1.65101483e-04,   2.10594100e-03,   1.77531822e-02,   1.00184949e-01,   3.86314902e-01,   1.05253567e+00,
         2.13614224e+00,   3.47263490e+00,   4.86345172e+00,   6.10446628e+00,   6.89633846e+00,   7.05898768e+00,
         6.80079466e+00,   6.58931865e+00,   6.73556074e+00,   7.09358899e+00,   7.22388382e+00,   6.95124093e+00,
         6.66449480e+00,   6.79247053e+00,   7.18691309e+00,   7.33892224e+00,   7.00596776e+00,   6.50093856e+00,
         6.39945082e+00,   6.86881134e+00,   7.40515913e+00,   7.43885875e+00,   7.03582836e+00,   6.73822343e+00,
         6.86853389e+00,   7.19400736e+00,   7.20734869e+00,   6.78128717e+00,   6.40969218e+00,   6.53882480e+00,
         7.00664597e+00,   7.33111185e+00,   7.24240152e+00,   6.85794537e+00,   6.35852557e+00,   5.66871120e+00,
         4.80953912e+00,   4.21555149e+00,   4.12108786e+00,   4.01005777e+00,   3.26093098e+00,   2.00756175e+00,
         8.94843135e-01,   2.81889916e-01,   6.17141163e-02,   9.26296295e-03,   9.41807115e-04,   6.41662293e-05,
         2.90135799e-06,   8.63544859e-08,   1.68057681e-09,   2.12742676e-11,   1.74484137e-13,   9.24466015e-16,
         3.15743044e-18,   6.94092823e-21,   9.80991086e-24,   8.90709766e-27,   5.19265001e-30,   1.94290475e-33,
         4.66445788e-37,   7.18374427e-41,   7.09640504e-45,   4.49592811e-49,   1.82667789e-53,   4.75930419e-58,
         7.95147107e-63,   8.51848333e-68,   5.85166404e-73,   2.57746455e-78,   7.27943754e-84])


### Lists for forces, positions, z-range, and simulation density
FRC=[];
z_list=[];
z_tmp = np.arange(zmin,zmax+zstep,zstep)
Rho = 0*z_tmp

### Construct the density using a gaussian distribution for each atom
for i in TargetList[:-1]:
    z = float(line_split[i-1].split()[4])
    z_list.append(z)
    Rho = Rho+((2*np.pi*1.5**2)**-0.5)*np.exp(-0.5*(z_tmp-z)**2./1.5**2.)

#############################
### Calculating the Force ###
#############################

### Energy = diference in density. There may be modifications to better performance at a later time.
U = Rho-Rho_EXP
    
### Calculating force using slope of U, alternatively it could be (R'-r') (Easily calculable)
for i in z_list:
    indx = int(np.floor((i-zmin)/zstep))
    FRC.append(-1.*(U[indx+1]-U[indx])/zstep)

#################################
### Writing the Force to File ###
#################################
               
TL_index=0; # Index of various lists at which atomid, z coordinate, or force will be found
for i in np.arange(0,len(line_split)-3):
    if i+1==TargetList[TL_index]: # When the index matches an atomid that needs a force
        ForceFile.write(`i+1`+' '+'0'+' '+`0.0`+' '+`0.0`+' '+`FRC[TL_index]`+'\n') # Write that index and the force
        TL_index+=1
    else:
        ForceFile.write(`i+1`+' '+'0'+' '+`0.0`+' '+`0.0`+' '+`0.0`+'\n') # If no force is needed, write the index and zero force.
ForceFile.write('0.0') 
ForceFile.close()


############################################################
### The format of the force file needs to be as follows: ###
###                                                      ###
###                                                      ###
### atomid replace fx fy fz                              ###
### atomid replace fx fy fz                              ###
###          .                                           ###
###          .                                           ###
###          .                                           ###
### energy                                               ###
### optional values                                      ###
############################################################
### replace tells how to apply the force (add or replace)
